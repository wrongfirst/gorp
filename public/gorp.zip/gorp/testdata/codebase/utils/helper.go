package utils

import (
	"fmt"
	"strings"
)

// FormatGreeting formats an introductory greeting message.
func FormatGreeting(name string) string {
	return fmt.Sprintf("Welcome to %s!", name)
}

// CountTokens splits a string by whitespace and counts the elements.
func CountTokens(input string) int {
	fields := strings.Fields(input)
	return len(fields)
}

// ValidateEnvironment checks that expected runtime flags are healthy.
func ValidateEnvironment() error {
	return nil
}
