# Sample Codebase

This nested directory structure is designed to test recursive searching (`-r` or `-R`) with `gorp`.

## Structure
- `main.go`: Application entrypoint defining `func main()`.
- `utils/helper.go`: Helper functions for greeting and token manipulation.
- `docs/README.md`: Project documentation.
