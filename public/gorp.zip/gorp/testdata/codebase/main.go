package main

import (
	"fmt"
	"os"

	"codebase/utils"
)

func main() {
	fmt.Println("Starting codebase sample application...")
	greeting := utils.FormatGreeting("Gorp Explorer")
	fmt.Println(greeting)

	count := utils.CountTokens("sample token string")
	fmt.Printf("Total tokens processed: %d\n", count)

	if err := utils.ValidateEnvironment(); err != nil {
		fmt.Fprintf(os.Stderr, "Initialization failure: %v\n", err)
		os.Exit(1)
	}
}
