package display

import "strings"

// ANSI color escape sequences.
const (
	ColorReset   = "\033[0m"
	ColorRed     = "\033[31m"
	ColorBoldRed = "\033[1;31m"
)

// ColorOption controls when ANSI terminal colors should be emitted.
type ColorOption string

const (
	ColorAlways ColorOption = "always"
	ColorNever  ColorOption = "never"
	ColorAuto   ColorOption = "auto"
)

// ParseColorOption converts a string option into a ColorOption.
func ParseColorOption(val string) ColorOption {
	switch strings.ToLower(val) {
	case "always":
		return ColorAlways
	case "never":
		return ColorNever
	case "auto", "":
		return ColorAuto
	default:
		return ColorAuto
	}
}

// ShouldColor determines if color output should be enabled based on option, isTTY, and noColorSet.
func ShouldColor(option ColorOption, isTTY bool, noColorSet bool) bool {
	switch option {
	case ColorAlways:
		return true
	case ColorNever:
		return false
	case ColorAuto:
		return isTTY && !noColorSet
	default:
		return false
	}
}

// HighlightMatches highlights all non-overlapping matches of pattern in line using bold red ANSI codes.
// Returns the formatted line and a boolean indicating whether any matches were found.
func HighlightMatches(line string, pattern string) (string, bool) {
	// TODO [Stage 3 Assembly]: Slices matched token positions and surrounds them with ANSI escape sequences.
	return line, false
}
