package display

import (
	"testing"
)

func TestParseColorOption(t *testing.T) {
	if ParseColorOption("ALWAYS") != ColorAlways {
		t.Errorf("expected ColorAlways")
	}
	if ParseColorOption("never") != ColorNever {
		t.Errorf("expected ColorNever")
	}
	if ParseColorOption("auto") != ColorAuto {
		t.Errorf("expected ColorAuto")
	}
	if ParseColorOption("unknown") != ColorAuto {
		t.Errorf("expected default ColorAuto")
	}
}

func TestShouldColor(t *testing.T) {
	tests := []struct {
		name       string
		opt        ColorOption
		isTTY      bool
		noColorSet bool
		want       bool
	}{
		{"always_tty", ColorAlways, true, false, true},
		{"always_notty", ColorAlways, false, false, true},
		{"always_nocolor", ColorAlways, true, true, true},
		{"never_tty", ColorNever, true, false, false},
		{"never_notty", ColorNever, false, false, false},
		{"auto_tty_no_nocolor", ColorAuto, true, false, true},
		{"auto_tty_with_nocolor", ColorAuto, true, true, false},
		{"auto_notty", ColorAuto, false, false, false},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			got := ShouldColor(tc.opt, tc.isTTY, tc.noColorSet)
			if got != tc.want {
				t.Errorf("ShouldColor(%v, %v, %v) = %v; want %v", tc.opt, tc.isTTY, tc.noColorSet, got, tc.want)
			}
		})
	}
}
