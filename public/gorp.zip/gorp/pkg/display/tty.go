package display

import (
	"os"
)

// IsTTY reports whether the given file descriptor is connected to a terminal (character device).
func IsTTY(f *os.File) bool {
	if f == nil {
		return false
	}
	stat, err := f.Stat()
	if err != nil {
		return false
	}
	return (stat.Mode() & os.ModeCharDevice) != 0
}

// IsStdoutTTY reports whether os.Stdout is connected to an interactive terminal.
func IsStdoutTTY() bool {
	return IsTTY(os.Stdout)
}

// HasNoColor reports whether the NO_COLOR standard environment variable is set.
func HasNoColor() bool {
	_, set := os.LookupEnv("NO_COLOR")
	return set
}
