package matcher

import "errors"

var (
	// ErrInvalidPattern is returned when a regular expression has syntax errors.
	ErrInvalidPattern = errors.New("matcher: invalid pattern syntax")

	// ErrNotImplemented indicates that this regex engine capability has not yet been built.
	ErrNotImplemented = errors.New("matcher: not implemented")
)

// Matcher represents a compiled regular expression matcher capable of testing input strings.
type Matcher interface {
	// Match reports whether the pattern matches anywhere within text.
	Match(text string) bool

	// Pattern returns the original regex pattern string.
	Pattern() string
}

// RegexEngine represents an engine that compiles a pattern into an executable Matcher.
type RegexEngine interface {
	Compile(pattern string) (Matcher, error)
}

// DefaultEngine is the global default engine used by Compile.
var DefaultEngine RegexEngine = &StubEngine{}

// Compile compiles a pattern using the default engine.
func Compile(pattern string) (Matcher, error) {
	return DefaultEngine.Compile(pattern)
}

// Match reports whether pattern matches text using the default engine.
func Match(pattern string, text string) (bool, error) {
	m, err := Compile(pattern)
	if err != nil {
		return false, err
	}
	return m.Match(text), nil
}

// StubEngine is a starter stub engine.
// Learners replace or extend this with the Backtracking and Thompson NFA engines
// built during the course.
type StubEngine struct{}

func (e *StubEngine) Compile(pattern string) (Matcher, error) {
	if pattern == "" {
		return nil, ErrInvalidPattern
	}
	return &StubMatcher{pattern: pattern}, nil
}

// StubMatcher is a starter Matcher stub.
type StubMatcher struct {
	pattern string
}

func (m *StubMatcher) Pattern() string {
	return m.pattern
}

func (m *StubMatcher) Match(text string) bool {
	// TODO [Stage 1]: Implement pattern matching across character classes,
	// anchors, quantifiers, and alternation.
	return false
}
