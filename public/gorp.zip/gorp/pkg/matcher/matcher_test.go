package matcher

import (
	"testing"
)

func TestCompileInterface(t *testing.T) {
	m, err := Compile("test")
	if err != nil {
		t.Fatalf("unexpected error compiling: %v", err)
	}
	if m.Pattern() != "test" {
		t.Errorf("expected pattern %q, got %q", "test", m.Pattern())
	}
}

func TestCompileEmptyPattern(t *testing.T) {
	_, err := Compile("")
	if err == nil {
		t.Error("expected error compiling empty pattern, got nil")
	}
}
