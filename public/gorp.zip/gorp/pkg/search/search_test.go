package search

import (
	"testing"
)

func TestMatchLineType(t *testing.T) {
	ml := MatchLine{
		Path:       "test.txt",
		LineNumber: 42,
		Line:       "hello world",
		Matches:    []string{"hello"},
	}
	if ml.LineNumber != 42 || ml.Path != "test.txt" {
		t.Errorf("unexpected MatchLine: %+v", ml)
	}
}
