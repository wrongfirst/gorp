package search

import (
	"io"

	"gorp/pkg/matcher"
)

// MatchLine records a single matched line with its line number and context.
type MatchLine struct {
	Path       string
	LineNumber int
	Line       string
	Matches    []string
}

// SearchReader scans an io.Reader line-by-line, matching lines against m.
// If invert is true, lines that do NOT match are returned.
func SearchReader(r io.Reader, m matcher.Matcher, invert bool) ([]MatchLine, error) {
	// TODO [Stage 4 Assembly]: Implement streaming line-by-line scanning using bufio.Scanner.
	return nil, nil
}

// SearchFile opens the file at path and scans it for matching lines.
func SearchFile(path string, m matcher.Matcher, invert bool) ([]MatchLine, error) {
	// TODO [Stage 4 Assembly]: Open file with os.Open, ensure defer Close(), and pass to SearchReader.
	return nil, nil
}
