package search

import (
	"gorp/pkg/matcher"
)

// SearchDirectory recursively traverses the directory tree rooted at root,
// scanning files for matches.
func SearchDirectory(root string, m matcher.Matcher, invert bool) ([]MatchLine, error) {
	// TODO [Stage 4 Assembly]: Recursively walk directory using filepath.WalkDir,
	// searching non-directory files with SearchFile.
	return nil, nil
}
