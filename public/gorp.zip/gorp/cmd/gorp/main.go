package main

import (
	"flag"
	"fmt"
	"io"
	"os"

	"gorp/pkg/matcher"
)

func printUsage() {
	fmt.Fprintf(os.Stderr, "Usage: gorp [OPTIONS] PATTERN [FILE...]\n\n")
	fmt.Fprintf(os.Stderr, "Search for PATTERN in standard input or files.\n\n")
	fmt.Fprintf(os.Stderr, "Options:\n")
	fmt.Fprintf(os.Stderr, "  -n, --line-number       Prefix each line with 1-based line number\n")
	fmt.Fprintf(os.Stderr, "  -v, --invert-match      Invert the sense of matching, selecting non-matching lines\n")
	fmt.Fprintf(os.Stderr, "  -o, --only-matching     Show only the part of a line matching PATTERN\n")
	fmt.Fprintf(os.Stderr, "  -r, -R, --recursive     Recursively search subdirectories\n")
	fmt.Fprintf(os.Stderr, "      --color[=WHEN]      Colorize matches: 'always', 'never', or 'auto' (default 'auto')\n")
	fmt.Fprintf(os.Stderr, "  -h, --help              Display this help and exit\n")
}

func main() {
	code := run(os.Args[1:], os.Stdin, os.Stdout, os.Stderr)
	os.Exit(code)
}

func run(args []string, stdin io.Reader, stdout io.Writer, stderr io.Writer) int {
	flags := flag.NewFlagSet("gorp", flag.ContinueOnError)
	flags.SetOutput(stderr)

	var (
		lineNumber   bool
		invertMatch  bool
		onlyMatching bool
		recursive    bool
		colorOptStr  string
	)

	flags.BoolVar(&lineNumber, "n", false, "Prefix line numbers")
	flags.BoolVar(&lineNumber, "line-number", false, "Prefix line numbers")
	flags.BoolVar(&invertMatch, "v", false, "Invert match")
	flags.BoolVar(&invertMatch, "invert-match", false, "Invert match")
	flags.BoolVar(&onlyMatching, "o", false, "Only matching")
	flags.BoolVar(&onlyMatching, "only-matching", false, "Only matching")
	flags.BoolVar(&recursive, "r", false, "Recursive search")
	flags.BoolVar(&recursive, "R", false, "Recursive search")
	flags.BoolVar(&recursive, "recursive", false, "Recursive search")
	flags.StringVar(&colorOptStr, "color", "auto", "Colorize output: always, never, auto")

	if err := flags.Parse(args); err != nil {
		if err == flag.ErrHelp {
			printUsage()
			return 0
		}
		return 2
	}

	remaining := flags.Args()
	if len(remaining) == 0 {
		printUsage()
		return 2
	}

	pattern := remaining[0]
	m, err := matcher.Compile(pattern)
	if err != nil {
		fmt.Fprintf(stderr, "gorp: %v\n", err)
		return 2
	}

	// TODO [Stage 1 Assembly]: Implement line-by-line scanning from stdin,
	// match lines using m.Match(line), output matches to stdout, and return
	// standard exit codes:
	//   0: At least one line matched
	//   1: No lines matched
	//   2: Error occurred
	_ = m
	_ = lineNumber
	_ = invertMatch
	_ = onlyMatching
	_ = recursive
	_ = colorOptStr
	_ = stdin
	_ = stdout

	return 0
}
